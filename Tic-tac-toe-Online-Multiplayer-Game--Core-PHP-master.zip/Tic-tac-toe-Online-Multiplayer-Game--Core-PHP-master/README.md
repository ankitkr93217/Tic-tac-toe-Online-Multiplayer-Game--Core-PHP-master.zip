# Tic-tac-toe-Online-Multiplayer-Game--Core-PHP
A Complete Tic-tac-toe Multiplayer online game.(Developed By: Sheikh Muhammad Adeel). Coded on Core PHP using Ajax. A user can register first then can see all the users online on the site. User can challenge any online user. A challenge notification will appear at the other user. User can accept challenge and the game will automatically start and both players can play their moves. Moves of both players will be live on both side. Play Again option is also their. Scores of both will also be mantained.

For any query Contact : Email: smaa.link@gmail.com
